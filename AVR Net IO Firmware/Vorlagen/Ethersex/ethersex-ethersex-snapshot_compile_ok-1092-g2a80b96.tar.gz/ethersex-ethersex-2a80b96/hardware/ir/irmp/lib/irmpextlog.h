#ifndef _IRMPEXTLOG_H
#define _IRMPEXTLOG_H

void    initextlog (void);
void    sendextlog (unsigned char);

#endif
