IRMP - Infrared Multi Protocol Decoder
--------------------------------------

Version IRMP:  2.6.7 19.09.2014
Version IRSND: 2.6.4 15.09.2014

Dokumentation:
 
   http://www.mikrocontroller.net/articles/IRMP
