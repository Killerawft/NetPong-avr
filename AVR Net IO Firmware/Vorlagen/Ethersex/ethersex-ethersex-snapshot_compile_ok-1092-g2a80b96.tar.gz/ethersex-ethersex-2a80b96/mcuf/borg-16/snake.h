/*
Copyright (C) 2009 Stefan Riepenhausen <rhn@gmx.net> (changes for ethersex)
Copyright (C) pre2009 http://www.das-labor.org 
Original codebase SVN: 
svn co https://roulette.das-labor.org/svn/microcontroller/src-atmel/borg/borg-16
Copyright (c) pre2009 by Guido Pannenbecker <info@sd-gp.de>

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 3 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE. See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, see <http://www.gnu.org/licenses/>.
*/

#ifndef BORG16_SNAKE_H
#define BORG16_SNAKE_H

void snake();

#endif /* BORG16_SNAKE_H */
